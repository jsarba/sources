from simplexml import *

class initXml:
	def __init__(self, file):
		self.prop = ('pgrp', 'groups', 'home', 'shell', 'admin', 'roles')
		self.d_val = ""
		self.p_item = ""
		try:
			self.fd = xmldoc(file)
		except:
			print 'Could not open file %s' % file
			return 0

	def str_format(self, path, key, item):
		ret = path + "(clave=%s)/%s" % (key, item)
		return ret

	def get_elements(self, search):
		ret = self.fd.elements(search)
		return ret[0]

	def __del__(self):
		del self.fd

class ParseXml(initXml):
	def getprop_item(self, key, path, parent):
		for element in self.fd.elements(path):
			self.__clave = element.attr(parent)
			if self.__clave == key:
				separator = ''
				for j in self.prop:
					search = self.str_format(path, self.__clave, j)
					try:
						self.__parent = self.get_elements(search)
						self.p_item += separator
						self.p_item += "%s=\'%s\'" % (j, self.__parent)
					except:
						pass
					separator = ','


if __name__ == '__main__':
	path = 'perfiles/perfil'
	parent = 'clave'

	pxml = ParseXml('perfiles.xml') 	
	pxml.getprop_item('operac', path, parent)

	print pxml.p_item	
#	print pxml.n_list['operac']

	
