from simplexml import * 
import dialog

class initXml:
	def __init__(self, file):
		self.prop = ('pgrp', 'groups', 'home', 'shell', 'admin', 'roles')
		self.n_list = {}
		self.d_val = ""
		self.p_item = ""
		try:
			self.fd = xmldoc(file)
		except:
			print 'Could not open file %s' % file
			return 0

	def str_format(self, path, key, item):
		ret = path + "(clave=%s)/%s" % (key, item)
		return ret

	def get_elements(self, search):
		ret = self.fd.elements(search)
		return ret[0]

	def __del__(self):
		del self.fd

class ParseXml(initXml):
	def getall_values(self, path, parent, item):
		for element in self.fd.elements(path):
			self.__clave = element.attr(parent)
			search = self.str_format(path, self.__clave, item)
			self.__parent = self.get_elements(search)
			self.n_list[self.__clave] = "%s" % self.__parent
			
	def getkey_value(self, key, path, parent, item):
		for element in self.fd.elements(path):
			self.__clave = element.attr(parent)
			if key == self.__clave:
				try:
					search = self.str_format(path, self.__clave, item)
					self.d_val = self.get_elements(search)
				except:
					break

	def getprop_item(self, key, path, parent):
		for element in self.fd.elements(path):
			self.__clave = element.attr(parent)
			if self.__clave == key:
				separator = ''
				for j in self.prop:
					search = self.str_format(path, self.__clave, j)
					try:
						self.__parent = self.get_elements(search)
						self.p_item += separator
						self.p_item += "%s=\'%s\'" % (j, self.__parent)
					except:
						pass
					separator = ','


class Object:
	objname = {}
	objvalue = {}
	def __init__(self):
		Object.objname['X'] = "Group"
		Object.objname['Y'] = "Username"
		Object.objname['Z'] = "Profile"
		Object.objname['W'] = "Password"
		Object.objname['N'] = "Full name"

	def add_value(self, obj, val):
		self.objvalue[obj] = val
	
	def del_value(self, obj):
		del self.objvalue[obj]

class CmdList:
	def __init__(self):
		self.cmdlist = []
	
	def add_line(self, key, cmd):
		self.cmdlist.append((key, cmd))
	
	def del_line(self, key, cmd):
		pass

	def del_last(self):
		pass

class TaskSave(Object, CmdList):
	def __init__(self, name):
		self.tsk_name = name
		self.obj = Object.__init__(self)
		self.cmd = CmdList.__init__(self)

	def __del__(self):
		self.tsk_name = ""
		del self.obj
		del self.cmd

class initScreen:
	def __init__(self):
		self.h = 0
		self.d = dialog.Dialog(dialog="dialog", compat="dialog")

	def makemenu(self, st, t, h, mh, w, cs):
		return self.d.menu(st, height=h, menu_height=mh, width=w, choices=(cs), title=t)

class InstanceWM(initScreen):
	def tittle(self, name):
		self.d.add_persistent_args(["--backtitle", name])

	def SimpleMenu(self, topmenu, subhead, header,  w):
		submenu = []
		mh = len(topmenu)
		h = mh + 7
		for menu in topmenu:
			submenu.extend([[ menu[0], ""]])

		if subhead:
			subhead = "Actual task:%s" % subhead
		else:
			subhead = ""

		(self.code, self.tag ) = self.makemenu(subhead, header, h, mh, w, submenu)

	def MultiMenu(self, topmenu, subhead, header, w):
		mh = len(topmenu)
		if self.h == 0:
			self.h = mh + 9
		return self.makemenu(subhead, header, self.h, mh, w, topmenu)

	def key_handle(self):
		d = self.d	# shorcut
		if self.code in (d.DIALOG_CANCEL, d.DIALOG_ESC):
			return 0
		else:
			return self.tag
