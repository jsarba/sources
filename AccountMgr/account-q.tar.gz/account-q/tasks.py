import cPickle as pick
from classes import *
from profile import *
import commands
import re, sys

DIRECTIVES = 'directivas.xml'
dir_item = 'directives/directive'
dir_parent = 'clave'

PASS_GEN = "./pass 8"

def SetAllObjects(s, dxml, tasks, tsv):
	for k in tasks:
		dxml.getkey_value(k, dir_item, dir_parent, 'name')

		if not dxml.d_val:
			return 0

		directive = dxml.d_val
		raw = re.compile('%[a-z]+%', re.IGNORECASE)
		iteret = raw.finditer("%s" % dxml.d_val)

		subraw = re.compile('[a-z]+', re.IGNORECASE)

		for i in iteret:
			tent = ""
			subret = subraw.search("%s" % i.group())
			j = subret.group()

			# 
			if tsv.objname[j] == 'Password':
				tent = commands.getoutput(PASS_GEN)
			if tsv.objname[j] == 'Profile':
				(code, tag) = get_profile(s, tsv.tsk_name)
			else:
				(code, tag) = s.d.inputbox("%s\n\n" % directive + tsv.objname[j] + 
					"(%s):" % i.group(), title="Objects", width=50, init=tent)

			if code in (s.d.DIALOG_CANCEL, s.d.DIALOG_ESC) or not tag:
				return 0

			tsv.add_value(j, tag)

			cmdline = "%s" % dxml.getkey_value(k, dir_item, dir_parent, 'cmd')
			p = re.compile(i.group())

			value = "%s" % (p.sub(tsv.objvalue[j], cmdline))
			tsv.add_line(k, value)

	return 1

def task_create(s, title, tsv):
	ls_key = []

	dxml = ParseXml(DIRECTIVES)
	dxml.getall_values(dir_item, dir_parent, 'name')
	
	n_list = len(dxml.n_list)
	added = ""
	
	while n_list:
		name_list = dxml.n_list.items()
		if len(ls_key) > 0:
			name_list.append(["APPLY", "Apply changes"])

		(code, tag) = s.MultiMenu(name_list, 
			"Task Name: %s\nAdded:\n%s" % (tsv.tsk_name, added), "Choice directives", 60)

		if code in (s.d.DIALOG_CANCEL, s.d.DIALOG_ESC):
			return 
		else:
			if tag == 'APPLY':
				break
			else:
				n_list -= 1
				added = added + " - %s\n" % dxml.n_list[tag]
				ls_key.append(tag)
				del dxml.n_list[tag]

	ret = SetAllObjects(s, dxml, ls_key, tsv)
	del dxml
	return ret

def task_save(s, title, tsv):
	(code, tag) = s.d.inputbox("FileName:", title=title, height=8, init=tsv.tsk_name)	

	if code in (s.d.DIALOG_CANCEL, s.d.DIALOG_ESC) or not tag:
		return 0

	filename = "%s.dat" % tag
	fd = open(filename, 'w')
	pick.dump(tsv, fd)

	return 1
	

	

